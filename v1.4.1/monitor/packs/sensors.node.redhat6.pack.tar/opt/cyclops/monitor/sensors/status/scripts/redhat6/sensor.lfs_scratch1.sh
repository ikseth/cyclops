#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#-O %fsname";"%status

#source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="lustre_fs1"
_sensor_status="CHECKING"

_fs_name="scratch1"
_chklfs=$( mount | grep $_fs_name 2>/dev/null >/dev/null ; echo $? )

[ "$_chklfs" == "0" ] && _sensor_status="UP mount" || _sensor_status="FAIL umount"

echo $_sensor_name":"$_sensor_status"@"
