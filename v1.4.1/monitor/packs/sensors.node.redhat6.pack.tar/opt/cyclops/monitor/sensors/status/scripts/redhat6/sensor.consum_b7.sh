#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="consum_b7"
_sensor_status="CHECKING"

_bld_watt=$( ipmitool sensor | awk -F\| '$1 ~ "Blade Consum" { split ($2,w,".") ; print w[1] }' | sed 's/ //g' )

case "$_bld_watt" in
	[0-9]*)
		_sensor_status=$_bld_watt"w"
	;;
	"")
		_sensor_status="DISABLE no data"
	;;
	*)
		_sensor_status="UNKNOWN $_bld_watt"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"

