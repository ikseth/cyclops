#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="mcelog"
_sensor_status="CHECKING"

_mce_log_path="/var/log/mcelog"

[ -f "$_mce_log_path" ] && _sensor_status=$( awk 'BEGIN { _count=0 } { _now=systime() ; if ( $1 == "TIME" && $2 > _now-259200 ) { _count++ }} END { if ( _count == 0 ) { print "UP" } else { print "MARK "_count }}' /var/log/mcelog ) || _sensor_status="DISABLE no mce"

echo $_sensor_name":"$_sensor_status"@"

