#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ "$1" == "help" ] && echo "HELP: ipmi cpu temp sensor, options: [SENSOR NAME] [CPU SEARCH STRING] [FAIL|WARN]" && exit 0

_sensor_name=$1
_sensor_status="CHECKING"
_sensor_string=$2
_sensor_cmd=$( which ipmitool 2>/dev/null ) 
[ "$3" == "FAIL" ] && _sensor_msg="FAIL" || _sensor_msg="MARK"

if [ -z "$_sensor_cmd" ]
then 
	_sensor_status="DISABLE no cmd"
else
	_cpu=$( $_sensor_cmd sensor | awk -F\| -v _ss="$_sensor_string" '$1 ~ _ss { _cpu = $2 * 100 / $8 ; _suma = _suma + _cpu ; _lines++ } END { _suma = _suma / _lines ; print _suma }' | cut -d'.' -f1 )

	if [ -z "$_cpu" ]
	then   
		_sensor_status="MARK sensor err"
	else   
		case "$_cpu" in
			[0-9]|[1-4][0-9])
				_sensor_status="UP $_cpu%"
			;;
			[3-7][0-9])
				_sensor_status="OK $_cpu%"
			;;
			8[0-9]|9[0-5])
				_sensor_status=$_sensor_msg" "$_cpu"%"
			;;
			1[0-9][0-9]|9[6-9])
				_sensor_status=$_sensor_msg" "$_cpu"%"
			;;
			*)
				_sensor_status="UNKNOWN $_cpu"
			;;
			esac
	fi
fi

echo $_sensor_name":"$_sensor_status"@"

