#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="sctrl_clt"
_sensor_status="CHECKING"
_hostname=$( hostname -s )

_scontrol=$(scontrol ping 2>/dev/null | head -n 1 | tr ' ' '\n' | sed -e 's/Slurmctld.\(.*\).$/\1/' -e '2 d' -e '4 d' | awk -F\/ '{ _c1=_c1";"$1 ; _c2=_c2";"$2 } END { print _c1";" ; print _c2";" }' | awk -F\; -v _h="$_hostname" 'BEGIN { _ctrl="DOWN" } $4 == "UP" { _ctrl="UP" } END { print _ctrl }')

case "$_scontrol" in
	"OK")
		_sensor_status="UP"	
	;;
	"DOWN")
		_sensor_status="DOWN down"
	;;
	"")
		_sensor_status="FAIL fail"
	;;
	*)
		_sensor_status="UNKNOWN $_scontrol"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
