#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ "$1" == "help" ] && echo "HELP: sensor help, options: [] []" && exit 0

_sensor_name="scontrol"
_sensor_status="CHECKING"
_hostname=$( hostname -s )

_scontrol=$(scontrol ping 2>/dev/null | head -n 1 | tr ' ' '\n' | sed -e 's/Slurmctld.\(.*\).$/\1/' -e '2 d' -e '4 d' | awk -F\/ '{ _c1=_c1";"$1 ; _c2=_c2";"$2 } END { print _c1";" ; print _c2";" }' | awk -F\; -v _h="$_hostname" '$4 == "UP" { if ( $3 ~ _h ) { print "OK" } else { print "DOWN" }}')

case "$_scontrol" in
	"OK")
		_sensor_status="UP"	
	;;
	"DOWN")
		_sensor_status="DOWN down"
	;;
	"")
		_sensor_status="FAIL fail"
	;;
	*)
		_sensor_status="UNKNOWN $_scontrol"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
