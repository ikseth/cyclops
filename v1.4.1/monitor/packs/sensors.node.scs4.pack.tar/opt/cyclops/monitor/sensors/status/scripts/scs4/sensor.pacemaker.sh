#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="pacemaker"
_sensor_status="CHECKING"

if /etc/init.d/corosync status 2>&1 >/dev/null
then
	_ha=$( haresl listprefs 2>/dev/null | awk '
		BEGIN { 
			_st="UP" 
		} $NF > 4 && $0 != "" && $1 != "resource" { 
			gsub(/\(running on:/,"ON") ; 
			gsub(/\(NOT running/,"OFF") ; 
			gsub(/\)/,"")
		} $3 ~ "^ON$|^OFF$" { 
			if ( $3 == "ON" && $2 != $4 && _st != "DOWN" && $2 != "None" ) { 
				_st="MARK" ; 
				_srvd=_srvd+1
			} else if ( $3 =="OFF" && $2 != "None" ) { 
				_st="DOWN" ; 
				_srvd=_srvd+1
			}
		} END { 
			if ( _st == "DOWN" || _st == "MARK" ) { 
				print _st" "_srvd 
			} else {  
				print _st 
			} 
		}' )

	[ -z "$_ha" ] && _sensor_status="DISABLE no data" || _sensor_status=$_ha
else
	_sensor_status="DOWN services off" 
fi

echo $_sensor_name":"$_sensor_status"@"
