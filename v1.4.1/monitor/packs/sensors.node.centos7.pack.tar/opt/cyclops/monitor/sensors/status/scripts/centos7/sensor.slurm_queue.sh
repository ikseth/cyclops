#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="slurm_squeue"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_hostname=$( hostname -s )

_sensor_status=$(squeue -w $_hostname | grep -v JOBID | wc -l)

echo $_sensor_name":"$_sensor_status"@"
