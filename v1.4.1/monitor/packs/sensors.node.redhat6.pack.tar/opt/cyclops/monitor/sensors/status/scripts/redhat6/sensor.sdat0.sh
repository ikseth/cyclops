#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#SENSOR PERSONALIZADO PARA DISCOS DUROS HGST SATA

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="sdat0" ## smartctl sda temperature
_sensor_status="CHECKING"

_sdatemp=$( smartctl --all /dev/sda | awk '$1 == "194" { _temp=$(NF-2)+40 ; _per=((_temp*100)/105) ; print int(_per) }' )

case "$_sdatemp" in
	[0-9]|[0-3][0-9])
		_sensor_status="MARK min"
	;;
	[4-5][0-9])
		_sensor_status="UP $_sdatemp%"
	;;
	[6-8][0-9])
		_sensor_status="OK $_sdatemp%"
	;;
	9[0-9]|[1-9][0-9][0-9])
		_sensor_status="MARK $_sdatemp%"
	;;
	"")
		_sensor_status="DISABLE sensor miss"
	;;
	*)
		_sensor_status="UNKNOWN $_sdatemp"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"

