#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ "$1" == "help" ] && echo "HELP: sensor help, options: [] []" && exit 0

_sensor_name="mem"
_sensor_status="CHECKING"

_mem=$( egrep "MemTotal|MemFree" /proc/meminfo | awk '{ print $2 }' | tr '\n' ' ' | awk '{ _percent=($2 * 100)/ $1 } END { print 100 - _percent }' | cut -d'.' -f1 )

case "$_mem" in
	[0-9]|[1-4][0-9])
		_sensor_status="UP $_mem%"
	;;
	[5-6][0-9])
		_sensor_status="OK $_mem%"
	;;
	100|[7-9][0-9])
		_sensor_status="CHECKING $_mem%"
	;;
	*)
		_sensor_status="UNKNOWN"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
