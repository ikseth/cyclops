#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="squeue"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_status=$(squeue -w $HOSTNAME | grep -v JOBID | wc -l)

echo $_sensor_name":"$_sensor_status"@"
