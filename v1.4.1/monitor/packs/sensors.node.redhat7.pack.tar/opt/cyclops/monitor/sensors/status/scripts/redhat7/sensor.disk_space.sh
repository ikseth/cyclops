#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

#COMENT#This sensor is adapted to BULL HPC SUIT, please modify egrep -v to filter or not desired filesystems

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="disk_space"
_sensor_status="CHECKING"

_space=$( df -l | awk '
	BEGIN { 
		_s="UP" 
	} $NF ~ "/" && $(NF -1) ~ "[0-9]+%" { 
		gsub(/%/,"",$(NF-1)) ; 
		$(NF-1) ; 
		if ( $(NF-1) > 75 && $(NF-1) < 85 ) { 
			_out=_out""$NF" "$(NF-1)"% " ; 
			if ( _s != "FAIL" ) { 
				_s="MARK" 
			} 
		} ; 
		if ( $(NF-1) >= 85 ) { 
			_out=_out""$NF" "$(NF-1)"% " ; 
			_s="FAIL" 
		} 
	} END { 
		print _s" "_out 
	}' | tr -d '\n' )

[ -z "$_space" ] && _sensor_status="MARK sens fail" || _sensor_status=$_space

echo $_sensor_name":"$_sensor_status"@"
