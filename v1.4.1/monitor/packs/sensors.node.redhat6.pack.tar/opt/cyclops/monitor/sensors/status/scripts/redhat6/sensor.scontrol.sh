#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="scontrol"
_sensor_status="CHECKING"

#_scontrol=$(scontrol ping 2>/dev/null | head -n 1 | tr ' ' '\n' | sed -e 's/Slurmctld.\(.*\).$/\1/' -e '2 d' -e '4 d' | awk -F\/ '{ _c1=_c1";"$1 ; _c2=_c2";"$2 } END { print _c1";" ; print _c2";" }' | awk -F\; -v _h="$HOSTNAME" '$4 == "UP" { if ( $3 ~ _h ) { print "OK" } else { print "DOWN" }}')

_scontrol=$( scontrol ping 2>/dev/null | head -n 1 | tr ' ' '\n' | sed -e 's/Slurmctld.\(.*\).$/\1/' -e '2 d' -e '4 d' | awk -F\/ '{ _c1=_c1";"$1 ; _c2=_c2";"$2 } END { print _c1";" ; print _c2";" }' | 
		awk -F\; -v _h="$HOSTNAME" '
			BEGIN { 
				_ctrl="DOWN" 
			} $4 == "UP" { 
				if ( $3 ~ _h && $2 == "primary" ) { _ctrl="OK" } else if ( $3 ~ _h && $2 == "backup" ) { _ctrl="UP" }
			} END { 
				print _ctrl 
			}' )

case "$_scontrol" in
	"OK")
		_sensor_status="OK primary"	
	;;
	"UP")
		_sensor_status="UP backup"
	;;
	"DOWN")
		_sensor_status="DOWN down"
	;;
	"")
		_sensor_status="FAIL fail"
	;;
	*)
		_sensor_status="UNKNOWN $_scontrol"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
