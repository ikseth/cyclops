#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ "$1" == "help" ] && echo "HELP: smartdisk status sensor, options: [SENSOR NAME] [DISK DEVICE] [% WARNING LEVEL]" && exit 0

_sensor_name=$1
_sensor_status="CHECKING"
_snsdisk="/dev/"$2

[ -z "$3" ] && _wrnlvl="1000" || _wrnlvl=$3 

_smart_disk=$( smartctl -H $_snsdisk | awk '$0 ~ "SMART overall-health self-assessment test result:" { print $NF }' )
_disk_data=$(  smartctl --attributes $_snsdisk | awk '$1 == "9" { _day=int($10/24) } END { print _day }' )

case $_smart_disk in
        PASSED|OK)
                [ "$_disk_data" -gt "$_wrnlvl" ] && _sensor_status="MARK "$_disk_data"d" || _sensor_status="UP "$_disk_data"d"
        ;;
        "SMART Disabled"*)
                _sensor_status="FAIL disabled"
        ;;
        "FAILED!")
                _sensor_status="FAIL $_sensor_disk"
        ;;
	"no disk")
		_sensor_status="DISABLE "$_smart_disk
	;;
        "")
                _sensor_status="DISABLE no data"
        ;;
        *)
                _disk_err=$_smart_disk" "$_sensor_disk
                _sensor_status="UNKNOWN "$_disk_err
        ;;
esac
	
echo $_sensor_name":"$_sensor_status"@"
