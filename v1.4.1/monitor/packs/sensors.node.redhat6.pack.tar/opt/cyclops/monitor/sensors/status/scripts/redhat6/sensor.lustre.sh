#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#-O %fsname";"%status

#source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="lustre"
_sensor_status="CHECKING"


_shine=$(shine -O %fsname";"%status -H status -n $HOSTNAME 2>/dev/null | grep "$HOSTNAME$" |  sed '/^$/d' | awk '{ print $3}' | sort -u )

[ -z "$_shine" ] && _shine="DISABLE"

case $_shine in
	failed$)
	_sensor_status="FAIL"
	;;
	"incoherent client state for FS*")
	_sensor_status="FAIL inconsisten state"
	;;
	offline*)
	_sensor_status="FAIL offline"
	;;
	"mounted *")
	_sensor_status="FAIL connecting"
	;;
	mounted)
	_sensor_status="UP mount"
	;;	
	mount*)
	_sensor_status="DOWN down"
	;;
	online*)
	_sensor_status="OK online"
	;;
	recovering*)
	_sensor_status="FAIL recovering"
	;;
	"CHECK FAILURE")
	_sensor_status="DOWN recovering"
	;;
	DISABLE)
	_sensor_status="DISABLE not configured"
	;;
	ERROR)
	_sensor_status="FAIL error"
	;;
	*)
	_sensor_status="UNKNOWN"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
