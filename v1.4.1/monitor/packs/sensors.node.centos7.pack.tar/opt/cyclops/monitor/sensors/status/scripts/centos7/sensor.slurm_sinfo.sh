#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="slurm_sinfo"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_hostname=$( hostname -s )

_sensor_status=$(sinfo -n $_hostname 2>&1 > /dev/null ; echo $? )

[ "$_sensor_status" -eq 0 ] && _sensor_status="UP" || _sensor_status="DOWN down"

echo $_sensor_name":"$_sensor_status"@"
