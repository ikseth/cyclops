#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ $1 == "help" ] && echo "HELP: smartd disk celsius temperature sensor, options: [SENSOR NAME] [STORAGE DEVICE]" >&2 && exit 0

_sensor_name=$1
_sensor_status="CHECKING"

_stg_dev="/dev/$2"
[ -z "$3" ] && _stg_cod="190" || _stg_cod=$3

_sdt_cmd=$( which smartctl 2>/dev/null )

if [ -z "$_sdt_cmd" ]
then
	_sensor_status="DISABLE no cmd" 
else
	_sensor_status=$( $_sdt_cmd --xall $_stg_dev | awk -v _sc="$_stg_cod" '
		$1 == _sc && NF > 6 { 
			if ( $NF ~ "/" ) {
				_temp=$(NF-2) 
			} else {
				_temp=$NF
			}
		} $0 ~ "Min/Max Temperature Limit" {
			_tl=$(NF-1) ;
			split(_tl,lt,"/")
		} $0 ~ "Min/Max recommended Temperature" {
			_tr=$(NF-1) ;
			split(_tr,rt,"/")
		} END {
			if ( _temp > rt[1] && _temp < rt[2] ) { print "UP "_temp }
			if ( _temp > lt[1] && _temp < rt[1] ) { print "MARK "_temp }
			if ( _temp > rt[2] && _temp < lt[2] ) { print "MARK "_temp }
			if ( _temp < lt[1] || _temp > lt[2] ) { print "DOWN "_temp }
		}' )

	[ -z "$_sensor_status" ] && _sensor_status="DISABLE sensor miss"
fi

echo $_sensor_name":"$_sensor_status"@"

