#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="hostname"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_status=`echo $HOSTNAME` 

echo $_sensor_name":"$_sensor_status"@"
