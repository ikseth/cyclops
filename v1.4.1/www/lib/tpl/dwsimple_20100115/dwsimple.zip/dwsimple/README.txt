dwsimple Template (http://wiki.splitbrain.org/wiki:tpl:dwsimple)
for DokuWiki (http://wiki.splitbrain.org/wiki:dokuwiki) version rc2006-10-08

version: 2008-03-25
author: Dietrich Wittenberg <info@wwwittenberg.de> 
