#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="disk_space"
_sensor_status="CHECKING"

_space=`df -l | grep -v bullxscs4 | egrep "9[0-9]%|100%" | awk '{ print $NF" "$(NF-1) }' | tr '\n' ' '`

if [ -z "$_space" ]
then
	_sensor_status="UP"
else
	_sensor_status="FAIL "$_space
fi

echo $_sensor_name":"$_sensor_status"@"
