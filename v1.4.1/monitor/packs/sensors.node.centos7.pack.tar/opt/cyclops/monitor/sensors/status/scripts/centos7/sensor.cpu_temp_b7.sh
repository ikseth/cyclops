#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="cpu_temp"
_sensor_status="CHECKING"

_blade_temp=$( ipmitool sensor | awk -F\| '$1 ~ "Blade Temp" { print $2 * 100 / $10 }' | cut -d'.' -f1 )

if [ -z "$_blade_temp" ]
then   
        _sensor_status="MARK sensor err"
else   
        case "$_blade_temp" in
                [0-9]|[1-4][0-9])
                        _sensor_status="UP $_blade_temp%"
                ;;
                [3-5][0-9]|6[0-5])
                        _sensor_status="OK $_blade_temp%"
                ;;
		6[6-9]|[7-8][0-9])
			_sensor_status="FAIL $_blade_temp%"
		;;
                100|9[0-9])
                        _sensor_status="DOWN $_blade_temp%"
                ;;
                *)
                        _sensor_status="UNKNOWN $_blade_temp"
                ;;
                esac
fi

echo $_sensor_name":"$_sensor_status"@"

