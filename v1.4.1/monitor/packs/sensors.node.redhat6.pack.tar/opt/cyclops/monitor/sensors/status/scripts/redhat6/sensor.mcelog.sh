#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="log_err"
_sensor_status="CHECKING"

[ -f "/etc/cyclops/global.cfg" ] && source /etc/cyclops/global.cfg ## OWN EXEC ##

_mce_log_file="/var/log/mcelog"
_tmp_file="/tmp/mcelog.cyc"

_mce_wrng="1"
_mce_fail="40"

if [ -f "$_tmp_file" ] && [ -f "$_mce_log_file" ] 
then
	_time_thr=$( stat -c %Z $_tmp_file )
	_sensor_status=$( awk -v _tr="$_time_thr" -v _mw="$_mce_wrng" -v _mf="$_mce_fail" '
		BEGIN { 
			_now=systime() ;
			_err=0 ;
		} $1 == "TIME" &&  $2 > _tr && $2 < _now {
			_err++ ;
		} END {
			if ( _err == 0 ) { _st="UP" ; _err="" }
			if ( _err >= _mw  ) { _st="MARK" }
			if ( _err >= _mf ) { _st="FAIL" }
			print _st" "_err ;
		}' $_mce_log_file ) 
else
	
	[ ! -f "$_tmp_file" ] && _sensor_status="DISABLE notime"
	[ ! -f "$_mce_log_file" ] && _sensor_status="MARK nolog"	
fi

echo $( date +%s ) > $_tmp_file


echo $_sensor_name":"$_sensor_status"@"
