#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="s1912"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_hostname=$( hostname -s )
_log_file="/var/log/slurm/slurmd.log.$_hostname"
_time_threshold=300
_now_time=$( date +%s )

[ -f "$_log_file" ] && _log_err_num=$( awk -v _tt="$_time_threshold" 'BEGIN { _now=systime() ; _c=0 } { _a=gensub(/.(....)-(..)-(..)T(..):(..):(..)...../,"\\1 \\2 \\3 \\4 \\5 \\6","g",$1) ; _ts=mktime( _a ) } _ts >= _now - _tt && $0 ~ "error: _rpc_launch_tasks: unable to send return code to address"  { _c++ } END { print _c } ' $_log_file ) || _log_err_num="no log"

case "$_log_err_num" in
	0)
		_sensor_status="UP"
	;;
	[1-9]*)
		_sensor_status="MARK "$_log_err_num
	;;
	"no log")
		_sensor_status="DISABLE $_log_err_num"
	;;
	*)
		_sensor_status="UNKN"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
