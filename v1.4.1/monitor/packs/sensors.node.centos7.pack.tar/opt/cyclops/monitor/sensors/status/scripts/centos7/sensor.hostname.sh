#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="hostname"
_sensor_status="CHECKING"

[ "$1" == "help" ] && echo "HELP: sensor help, options: [] []" && exit 0

_sensor_status=$( hostname -s ) 

echo $_sensor_name":"$_sensor_status"@"
