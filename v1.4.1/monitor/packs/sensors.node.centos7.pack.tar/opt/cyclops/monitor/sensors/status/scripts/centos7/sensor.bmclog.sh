#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ "$1" == "help" ] && echo "HELP: ipmitool bmc events sensor, options: [SENSOR NAME] [FAIL|WARN]" && exit 0

_sensor_name="$1"
_sensor_status="CHECKING"
_sensor_cmd=$( which ipmitool 2>/dev/null )
[ $2 == "FAIL" ] && _sensor_msg="FAIL" || _sensor_msg="MARK"

if [ -z "$_sensor_cmd" ]
then
	_sensor_status="DISABLE no cmd" 
else
	_bios_log=$( $_sensor_cmd sel list 2>/dev/null | wc -l)

	if [ $_bios_log != 0 ]
	then
		_sensor_status=$_sensor_msg" "$_bios_log
	else
		_sensor_status="UP"
	fi
fi

echo $_sensor_name":"$_sensor_status"@"
