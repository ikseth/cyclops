#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#-O %fsname";"%status

[ "$1" == "help" ] && echo "HELP: sensor help, options: [] []" && exit 0

_sensor_name="mysql_sync"
_sensor_status="CHECKING"

_mysql_pass="slurm.dev.pass"
_mysql_sync_test=$( mysql -p$_mysql_pass -e 'SHOW SLAVE STATUS\G' | awk 'BEGIN { _fail="FAIL" } $1 ~ /Slave_[A-Z]*_Running/ { if ( $2 != "Yes" ) { _fail=_fail" "$1 } else { _ok++ }} END { if ( _ok == 2 )  { print "OK" } else { print _fail }}' )

case $_mysql_sync_test in
	FAIL*)
	_sensor_status=$_mysql_sync_test
	;;
	OK)
	_sensor_status=$_mysql_sync_test" sync"
	;;
	"")
	_sensor_status="MARK no data"
	;;	
	*)
	_sensor_status="UNKNOWN"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
