#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="smart_disk"
_sensor_status="CHECKING"

_local_disk_list=$( fdisk -l | grep -o "^Disk /dev/sd[a-z]" | cut -d' ' -f2 ) 

for _local_disk in $( echo "${_local_disk_list}" )
do

	_smart_disk=$( smartctl -H $_local_disk | grep -v "^===" |  egrep "SMART|Health Status|test result:" | cut -d':' -f2 | sed -e 's/^ //' ) 

	case $_smart_disk in
		PASSED|OK)
			_sensor_status="UP"
		;;
		"SMART Disabled"*)
			_sensor_status="FAIL disabled"
		;;
		*)
			_disk_err=$_smart_disk" "$_local_disk
			_sensor_status="UNKNOWN debug err: "$_disk_err
		;;
	esac
done
	
echo $_sensor_name":"$_sensor_status"@"
