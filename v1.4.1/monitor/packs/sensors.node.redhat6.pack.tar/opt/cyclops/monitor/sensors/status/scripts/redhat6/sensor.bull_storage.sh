#!/bin/bash
#@HELP@
#@SCOPY@
#@NODO@management
#@LOCAL@

_sensor_name="bull_storage"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_status=$( storadm show 2>/dev/null | awk 'BEGIN { _st="OK" } $1 ~ "da[0-9]" && ( $7 !~ "ok" || $8 !~ "ready" || $9 !~ "up" ) { _st=_st" "$1 } END { if ( _st == "OK" ) { print _st } else { print "FAIL"_st }}' )

echo $_sensor_name":"$_sensor_status"@"
