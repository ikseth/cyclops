#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="log_err"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_log_file="/var/log/syslog"
_tmp_file="/tmp/logerr.cyc"

if [ -f "$_tmp_file" ] && [ -f "$_log_file" ] 
then
	_time_thr=$( stat -c %Z $_tmp_file )
	_sensor_status=$( awk -v _tr="$_time_thr" 'BEGIN { _now=systime() ; _st="UP" } $1 > _tr && $1 < _now && $8 ~ /err|crit/ { _err++ ; _st="CHECKING" ; if ( $8 == "crit" ) { _st="MARK" }} END { print _st" "_err }' $_log_file )
else
	
	[ ! -f "$_tmp_file" ] && _sensor_status="DISABLE notime"
	[ ! -f "$_log_file" ] && _sensor_status="MARK nolog"	
fi

echo $( date +%s ) > $_tmp_file


echo $_sensor_name":"$_sensor_status"@"
