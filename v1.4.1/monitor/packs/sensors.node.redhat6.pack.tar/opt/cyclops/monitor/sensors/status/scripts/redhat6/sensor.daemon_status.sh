#!/bin/bash
#@HELP@ Needs to control distro and/or exec values, there can be "3:on/3:activo/on/activo".
#@SCOPY@
#@LOCAL@

_sensor_name="daemon_status"
_sensor_status="CHECKING"
_debug_code="SRSTDS01"

source /etc/cyclops/global.cfg ## OWN EXEC ##
export LANG="en_EN.UTF-8" ## OWN EXEC ##

_daemon_all=0
_daemon_bad=0
_daemon_ok=0

for _daemon in `chkconfig | awk '$5 ~ "3:on" { print $1 }'`
do
	let "_daemon_all++"

	if /etc/init.d/$_daemon status 2>/dev/null >/dev/null
	then
		let "_daemon_ok++"
	else
		let "_daemon_bad++"
	fi

done

if [ $_daemon_bad != 0 ] 
then 
	_sensor_status="FAIL /$_daemon_all/$_daemon_ok/$_daemon_bad/"
else
	_sensor_status="UP /$_daemon_all/$_daemon_ok/"	
fi

echo $_sensor_name":"$_sensor_status"@"
