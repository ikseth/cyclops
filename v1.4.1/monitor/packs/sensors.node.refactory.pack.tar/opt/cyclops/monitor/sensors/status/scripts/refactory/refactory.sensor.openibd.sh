#!/bin/bash

/etc/init.d/openibd status | grep HCA\ driver | sed 's/\ \ HCA\ driver\ loaded/UP/'
