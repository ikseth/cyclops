#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#-O %fsname";"%status

#source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="lustre_fs"
_sensor_status="CHECKING"

        _sensor_lustre_fs_cod=$( awk 'BEGIN { _code="21" } $3 == "lustre" { _code="0" } END { print _code }' /etc/fstab 2>/dev/null )
        if [ "$_sensor_lustre_fs_cod" == "0" ]
        then   
                _sensor_status="UP"
                _lustre_fs_count=0

                for _fs in $( awk '$3 == "lustre" { print $2 }' /etc/fstab 2>/dev/null )
                do
                        _sensor_lustre_fs_mnt=$( mount | awk -v _m="$_fs" 'BEGIN { _ms="1" } $3 == _m && $5 == "lustre" { _ms="0" } END { print _ms }' 2>/dev/null )
                        [ "$_sensor_lustre_fs_mnt" == "0" ] && _sensor_lustre_fs_mnt=$( ls -1 $_fs 2>&1 | grep "Stale file handle" | wc -l )
                        [ "$_sensor_lustre_fs_mnt" != "0" ] && let "_lustre_fs_count++"
                done

                [ "$_lustre_fs_count" != "0" ] && _sensor_status="FAIL "$_lustre_fs_count
        else   
                _sensor_status="FAIL no cfg"
        fi

echo $_sensor_name":"$_sensor_status"@"
