#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ "$1" == "help" ] && echo "HELP: slurm node status sensor, options: [SENSOR NAME] [partition] [mon control,FAIL|WARN]" && exit 0

_sensor_name=$1
_sensor_status="CHECKING"

_hostname=$( hostname -s )
_spart=$2

case $3 in 
	WARN|MARK)
		_sctrl="MARK"	
	;;
	FAIL)
		_sctrl="FAIL"
	;;
	*)
		_sctrl="FAIL"
	;;
esac

_sinfo_cmd=$( which sinfo 2>/dev/null )

if [ -z "$_sinfo_cmd" ] 
then
	_sensor_status="no cmd" 
else
	_sensor_status=$( exec $_sinfo_cmd -h -n $_hostname -p $_spart | awk '$2 == "up" { print $5 }' 2> /dev/null | sort -u )
fi

case $_sensor_status in
	idle)
	_sensor_status="UP idle"
	;;
	drng)
	_sensor_status="MARK go to drain"
	;;
	drain)
	_sensor_status=$_sctrl" maintenance"
	;;
	alloc|mix)
	_sensor_status="OK working"
	;;
	comp)
	_sensor_status="MARK completing"
	;;
	down)
	_sensor_status=$_sctrl" down - "$_sctrl
	;;
	"n/a")
	_sensor_status="DISABLE not configured"
	;;
	"no cmd")
	_sensor_status=$_sctrl" "$_sensor_status
	;;
	"")
	_sensor_status=$_sctrl" not comm"
	;;
	*)
	_sensor_status="UNKN unknown status"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
