#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

[ -f "/etc/cyclops/global.cfg" ] && source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="lu8246"
_sensor_status="CHECKING"

_lsfs=$( mount | awk -F\/ '$7 ~ "mdt" { print $6 }' )

_ldml_lim_file="/proc/fs/lustre/ldlm/namespaces/mdt-"$_lsfs"-MDT0000_UUID/pool/limit"
_ldml_gra_file="/proc/fs/lustre/ldlm/namespaces/mdt-"$_lsfs"-MDT0000_UUID/pool/granted"


if [ -f "$_ldml_lim_file" ] && [ -f "$_ldml_gra_file" ]
then
	_ldml_lim=$( cat $_ldml_lim_file )
	_ldml_gra=$( cat $_ldml_gra_file )
	[ "$_ldml_lim" -lt "$_ldml_gra" ] && _sensor_status="MARK "$_lsfs || _sensor_status="UP"
else
	_sensor_status="DISABLE no mdt"
fi

echo $_sensor_name":"$_sensor_status"@"
