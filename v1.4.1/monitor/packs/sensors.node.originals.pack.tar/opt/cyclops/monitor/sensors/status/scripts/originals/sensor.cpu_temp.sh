#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="cpu_temp"
_sensor_status="CHECKING"

_cpu=$( ipmitool sensor | awk -F\| '$1 ~ "CPU[0-9] Temp" { _cpu = $2 * 100 / $8 ; _suma = _suma + _cpu ; _lines++ } END { _suma = _suma / _lines ; print _suma }' | cut -d'.' -f1 )

if [ -z "$_cpu" ]
then   
        _sensor_status="MARK sensor err"
else   
        case "$_cpu" in
                [0-9]|[1-4][0-9])
                        _sensor_status="UP $_cpu%"
                ;;
                [3-5][0-9]|6[0-5])
                        _sensor_status="OK $_cpu%"
                ;;
		6[6-9]|[7-8][0-9])
			_sensor_status="FAIL $_cpu%"
		;;
                100|9[0-9])
                        _sensor_status="DOWN $_cpu%"
                ;;
                *)
                        _sensor_status="UNKNOWN $_cpu"
                ;;
                esac
fi

echo $_sensor_name":"$_sensor_status"@"

