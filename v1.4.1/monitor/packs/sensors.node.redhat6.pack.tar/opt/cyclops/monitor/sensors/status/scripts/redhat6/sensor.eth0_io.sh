#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@


_sensor_name="eth0_io"
_sensor_status="CHECKING"

_netdev="eth0"
_warn_level="30"
_tmp_file="/tmp/$_netdev.cyc"

_ifstatus=$( ip link | egrep ^.: | sed -e 's/.. \(.*\):.*state.\(.*\)/ \1 \2 /' | awk -v _if="$_netdev" '$1 == _if { print $2 }' )

if [ -f "$_tmp_file" ] && [ "$_ifstatus" == "UP" ] 
then
	_net_top=$( /sbin/ethtool $_netdev 2>/dev/null | awk '$0 ~ "Speed" { sub(/....$/,"",$2) ; print $2 }' )
        _net_ini=$( cat $_tmp_file )
        _net_thr=$( stat -c %Z $_tmp_file )
        _net_end=$( awk -v _nd="$_netdev" '{ sub(/:/,"",$1) } $1 == _nd { print $2";"$10 }' /proc/net/dev )
        _net_vel=$( echo "dummie" | awk -F\; -v _lt="$_net_thr" -v _ini="$_net_ini" -v _end="$_net_end" -v _top="$_net_top" -v _wl="$_warn_level" '
                BEGIN { 
                        split(_ini,i,";") ; 
                        split(_end,e,";") ; 
                        _top=(_top*1024*1024)/8 ; 
                        _ts=systime() ;
                        _tt=_ts-_lt
                        _st="UP" ;
                } { 
                        if ( _tt != 0 ) { 
                                _in=int((((( e[1]-i[1] )/_tt ) * 100 ) / _top )) ; 
                                _out=int((((( e[2]-i[2] )/_tt ) * 100 ) / _top ))
                        } else {
                                _in=0
                                _out=0
                        }
                } END { 
                        if ( _in > _wl || _out > _wl ) { _st="MARK" } ;
                        print _st" "_in"/"_out 
                }' )
else
	if [ "$_ifstatus" == "UP" ]
	then
		_net_end=$( awk -v _nd="$_netdev" '{ sub(/:/,"",$1) } $1 == _nd { print $2";"$10 }' /proc/net/dev )
		_net_vel="DISABLE"
	else
		_net_vel=$_ifstatus
	fi
fi

echo $_net_end > $_tmp_file 

_sensor_status=$_net_vel
echo $_sensor_name":"$_sensor_status"@"
