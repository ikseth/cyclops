#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="cpu0_temp_b7"
_sensor_status="CHECKING"

_cpu_temp=$( ipmitool sensor | awk -F\| '$1 ~ "CPU0 DTS value" { _tmp=$2+100 ; _max=$10+100 ; _total= ( _tmp * 100 ) / _max ; print _total  }' | cut -d'.' -f1 )

case "$_cpu_temp" in
	[0-9]|[1-7][0-9])
		_sensor_status="UP $_cpu_temp%"
	;;
	8[0-9])
		_sensor_status="OK $_cpu_temp%"
	;;
	1[0-9][0-9]|9[0-9])
	_sensor_status="DOWN $_cpu_temp%"
	;;
	"")
	_sensor_status="DISABLE sensor miss"
	;;
	*)
	_sensor_status="UNKNOWN $_cpu_temp"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"

