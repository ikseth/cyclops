#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@


_sensor_name="ib1_io"
_sensor_status="CHECKING"

_netdev="mlx4_1"
_warn_level="30"
_tmp_file="/tmp/$_netdev.cyc"

_ifstatus=$( ibstat $_netdev 1 2>/dev/null ) 
if [ -z "$_ifstatus" ]
then
	_ifstatus="DISABLE"
else
	 _ifstatus=$( echo "${_ifstatus}" | awk -F\: '$1 == "Physical state" { if ( $2 ~ "LinkUp" ) { _ctrl="UP" } else { _ctrl="DOWN "$2 }} END { print _ctrl }' ) 
fi

if [ -f "$_tmp_file" ] && [ "$_ifstatus" == "UP" ] 
then
	_net_top=56
        _net_ini=$( cat $_tmp_file )
        _net_thr=$( stat -c %Z $_tmp_file )
        _net_end=$( perfquery -x -C $_netdev -P 1 | awk -F\. '$1 == "PortRcvData:" { _in=$NF*4 } $1 == "PortXmitData:" { _out=$NF*4 } END { print _in";"_out }' )
        _net_vel=$( echo "dummie" | awk -F\; -v _lt="$_net_thr" -v _ini="$_net_ini" -v _end="$_net_end" -v _top="$_net_top" -v _wl="$_warn_level" '
                BEGIN { 
                        split(_ini,i,";") ; 
                        split(_end,e,";") ; 
                        _top=(_top*1000*1000*1000)/8 ; 
                        _ts=systime() ;
                        _tt=_ts-_lt
                        _st="UP" ;
                } { 
                        if ( _tt != 0 ) { 
                                _in=int((((( e[1]-i[1] )/_tt ) * 100 ) / _top )) ; 
                                _out=int((((( e[2]-i[2] )/_tt ) * 100 ) / _top ))
                        } else {
                                _in=0
                                _out=0
                        }
                } END { 
                        if ( _in > _wl || _out > _wl ) { _st="MARK" } ;
                        print _st" "_in"/"_out 
                }' )
else
	if [ "$_ifstatus" == "UP" ]
	then
		_net_end=$( perfquery -x -C $_netdev -P 1 | awk -F\. '$1 == "PortRcvData:" { _in=$NF*4 } $1 == "PortXmitData:" { _out=$NF*4 } END { print _in";"_out }' )
		_net_vel="DISABLE"
	else
		_net_vel=$_ifstatus
	fi
fi

echo $_net_end > $_tmp_file 

_sensor_status=$_net_vel
echo $_sensor_name":"$_sensor_status"@"
