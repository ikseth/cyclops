#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@
#-O %fsname";"%status

#source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="nfs_fs"
_sensor_status="CHECKING"

	_sensor_nfs_fs_cod=$( awk 'BEGIN { _code="21" } $3 == "nfs" { _code="0" } END { print _code }' /etc/fstab 2>/dev/null )
	if [ "$_sensor_nfs_fs_cod" == "0" ]
	then
		_sensor_status="UP"
		_nfs_fs_count=0

		for _fs in $( awk '$3 == "nfs" { print $2 }' /etc/fstab 2>/dev/null )
		do
			_sensor_nfs_fs_mnt=$( mount | awk -v _m="$_fs" 'BEGIN { _ms="1" } $3 == _m && $5 == "nfs" { _ms="0" } END { print _ms }' 2>/dev/null )
			[ "$_sensor_nfs_fs_mnt" == "0" ] && _sensor_nfs_fs_mnt=$( ls -1 $_fs 2>&1 | grep "Stale file handle" | wc -l )
			[ "$_sensor_nfs_fs_mnt" != "0" ] && let "_nfs_fs_count++"
		done

		[ "$_nfs_fs_count" != "0" ] && _sensor_status="FAIL "$_nfs_fs_count
	else
		_sensor_status="DISABLE"
	fi

echo $_sensor_name":"$_sensor_status"@"
