#! /bin/bash
# IPMI SCRIPT SENSOR use '_sensor_ipmi_output' to get data to process

_sensor_string="Spare Drives"
_sensor_search="Total hot spare drives:"

_sensor_output=$( echo "${_sensor_ipmi_output}" | awk -v _strg="$_sensor_search" 'BEGIN { _ctrl=0 } $0 ~ _strg { _ts=$NF ; _cus="MARK" } else { _status="UP" } print _status" "_ts"/"_ds"/"_us }' ) 

echo $_sensor_string":"$_sensor_status
