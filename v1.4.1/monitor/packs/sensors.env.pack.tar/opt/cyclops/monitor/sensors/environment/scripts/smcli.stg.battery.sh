#! /bin/bash
# IPMI SCRIPT SENSOR use '_sensor_ipmi_output' to get data to process

_sensor_string="Spare Drives"
_sensor_search="Batteries Detected:"

_sensor_output=$( echo "${_sensor_ipmi_output}" | awk -v _strg="$_sensor_search" '
	BEGIN { 
		_ctrl=0 
	} $0 ~ "Batteries Detected:" { 
		_bn=$NF ; 
		_ctrl=1 ; 
		_b=0 
	} _ctrl == 1 && $0 ~ "Battery status:" { 
		_b++ ; 
		bs[_b]=$NF 
	} END { 
		if ( _bn > 0 ) { 
			for (i=1;i<=_bn;i++) { 
				if ( bs[i] != "Optimal" ) { 
					_status="FAIL" ; 
					_fb++ 
				}
			} 
			if ( _fb > 0 ) { 
				print _status" "_fb 
			} else { 
				print "UP" 
			}
		} else { 
			print "DISABLE no batt" 
		}
	}' ) 

echo $_sensor_string":"$_sensor_status
