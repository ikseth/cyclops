<?php

/* --------------------------- */
/* cssc.php: 
   (c) by Dietrich Wittenberg) */

	include "simple.php";
	header("Content-type: text/css; charset=UTF-8"); //iso-8859-1
	createcss(dirname(__FILE__)."/cssc.xml");
/* --------------------------- */

?>
