#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="pacemaker"
_sensor_status="CHECKING"


if /etc/init.d/corosync status 2>&1 >/dev/null
then
	_ha=$( haresl listprefs 2>/dev/null | sed -e 's/(/"/' -e 's/)/"/' | awk -F\" '{OFS="\"";for(i=2;i<NF;i+=2)gsub(/ /,"_",$i);print}' | awk '$2 != "None" && $3 ~ /NOT_running/ { print $1 }' | tr '\n' ' ' | sed -e 's/ $//' -e 's/[_-.]//g' ) 
	if [ -z "$_ha" ]
	then
		_sensor_status="UP"
	else
		_sensor_status="DOWN $_ha"
	fi
else
	_sensor_status="DOWN services off" 
fi

echo $_sensor_name":"$_sensor_status"@"
