#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="ib_net"
_sensor_status="CHECKING"

_ib_net=$( ping -q -c 4 nfs-ib-server.bullx 2>&1 >/dev/null ; echo $? )

case $_ib_net in
	0)
	_sensor_status="UP"
	;;
	1)
	_sensor_status="FAIL timeout"
	;;
	[2-9])
	_sensor_status="FAIL err.$_ib_net"
	;;
	"")
	_sensor_status="FAIL no data"
	;;
	*)
	_sensor_status="UNKNOWN $_ib_net" 
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
