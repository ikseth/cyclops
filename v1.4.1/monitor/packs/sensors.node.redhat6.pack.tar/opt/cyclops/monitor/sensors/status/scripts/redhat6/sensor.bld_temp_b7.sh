#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="bld_temp"
_sensor_status="CHECKING"

[ -z "$_ipmi_sensor" ] && _ipmi_sensor=$( ipmitool sensor )

_bld_temp=$( echo "${_ipmi_sensor}" | awk -F\| '$1 ~ "Blade Temp" || $1 ~ "CSP Temp" { print $2 * 100 / $10 }' | cut -d'.' -f1 )

case "$_bld_temp" in
	[0-9]|[1-5][0-9]|6[0-5])
		_sensor_status="UP $_bld_temp%"
	;;
	6[6-9]|7[0-9]|8[0-5])
		_sensor_status="OK $_bld_temp%"
	;;
	8[6-9]|9[0-4])
		_sensor_status="MARK $_bld_temp%"
	;;
	9[5-8])
		_sensor_status="FAIL $_bld_temp%"
	;;
	1[0-9][0-9]|99)
		_sensor_status="DOWN $_bld_temp%"
	;;
	"")
		_sensor_status="DISABLE sensor miss"
	;;
	*)
		_sensor_status="UNKNOWN $_bld_temp"
	;;
esac

echo $_sensor_name":"$_sensor_status"@"

