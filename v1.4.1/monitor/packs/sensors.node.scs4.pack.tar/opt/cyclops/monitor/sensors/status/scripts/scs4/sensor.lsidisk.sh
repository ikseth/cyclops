#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

_sensor_name="lsidisk"
_sensor_status="CHECKING"

source /etc/cyclops/global.cfg ## OWN EXEC ##

_lsidisk=`/opt/MegaRAID/MegaCli/MegaCli64 -PdList -aAll | grep 'Drive has flagged a S.M.A.R.T alert : No' | wc -l`
let _lsidisk=$_lsidisk-2

if [ "$_lsidisk" == 0 ]
then
	_sensor_status="UP"
else
	_sensor_status="DOWN "$_lsidisk
fi

echo $_sensor_name":"$_sensor_status"@"
