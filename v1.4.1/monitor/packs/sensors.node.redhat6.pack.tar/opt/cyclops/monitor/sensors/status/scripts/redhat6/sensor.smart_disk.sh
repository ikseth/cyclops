#!/bin/bash
#@HELP@
#@SCOPY@
#@LOCAL@

source /etc/cyclops/global.cfg ## OWN EXEC ##

_sensor_name="smart_disk"
_sensor_status="CHECKING"
_sensor_disk="/dev/sda"


_smart_disk=$( smartctl -H $_sensor_disk | awk '$0 ~ "SMART overall-health self-assessment test result:" { print $NF }' ) 
_disk_data=$(  smartctl --attributes $_sensor_disk | awk '$1 == "9" { _day=int($10/24) } END { print _day }' )

case $_smart_disk in
	PASSED|OK)
		[ "$_disk_data" -gt 2200 ] && _sensor_status="MARK "$_disk_data"d" || _sensor_status="UP "$_disk_data"d"
	;;
	"SMART Disabled"*)
		_sensor_status="FAIL disabled"
	;;
	"FAILED!")
		_sensor_status="FAIL $_sensor_disk"
	;;
	"")
		_sensor_status="DISABLE no data"
	;;
	*)
		_disk_err=$_smart_disk" "$_sensor_disk
		_sensor_status="UNKNOWN "$_disk_err
	;;
esac

echo $_sensor_name":"$_sensor_status"@"
